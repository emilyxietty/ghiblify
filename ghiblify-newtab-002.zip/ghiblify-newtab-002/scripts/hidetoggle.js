jQuery(document).ready(function(){
    jQuery('#hideshow').on('click', function(event) {
        jQuery('#content').toggle('show');
    });
});

jQuery(document).ready(function(){
    jQuery('#hideshow1').on('click', function(event) {
        jQuery('#content1').toggle('show');
    });
});

jQuery(document).ready(function(){
    jQuery('#hideshow2').on('click', function(event) {
        jQuery('#content2').toggle('show');
    });
});
